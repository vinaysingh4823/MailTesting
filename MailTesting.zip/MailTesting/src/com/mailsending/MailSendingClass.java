package com.mailsending;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class MailSendingClass {

	public static void sendEmailToUser(String xlsFile, String userEmailId) {
		String output = "";
		StringBuilder result = new StringBuilder();
		OutputStreamWriter writer = null;
		String mailUrl = "";
		URL url = null;
		HttpURLConnection conn = null;
		String mailBody = "";
		BufferedReader br = null;
		try {
			mailBody = createEmailBodyText(xlsFile, userEmailId);
			mailUrl = "https://mligateway.maxlifeinsurance.com/mli/prod/soa/email/v4?client_id=b522c052-532f-4c4b-b80b-95dc18bcfdf3&client_secret=D2iC0cN8xD5xY0aB8dM5sD0vR8uG3kO3fC5wO7yX5oA1fK5hU3";
			url = new URL(mailUrl);
			conn = (HttpURLConnection) url.openConnection();
			HttpURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestMethod("POST");

			writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(mailBody);
			writer.flush();
			int apiResponseCode = conn.getResponseCode();
			if (apiResponseCode == 200) {
				br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
			} else {
				br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
		} catch (Exception e) {
			System.out.println("Exception occured :: " + e);
		} finally {
			try {
				if (writer != null) {
					writer.close();
				}
			} catch (Exception e1) {
				System.out.println("Exception occured :: " + e1);
			}
		}

	}

	private static String createEmailBodyText(String xlsFile, String userEmailId) {

		double randomNumber = Math.random();
		xlsFile = xlsFile.replaceAll("\n", "");
		StringBuilder mailReq = new StringBuilder();
		mailReq.append("{");
		mailReq.append("\"request\": {");
		mailReq.append("\"header\": {");
		mailReq.append("\"soaCorrelationId\": \"" + randomNumber + "\",");
		mailReq.append("\"soaAppId\": \"POS\"");
		mailReq.append("},");
		mailReq.append("\"requestData\": {");
		mailReq.append("\"mailIdTo\": \"" + userEmailId.toLowerCase() + "\",");
		mailReq.append("\"mailSubject\": \"mPRO-POSV2.0 Report\",");
		mailReq.append("\"fromName\": \"Maxlife Insurance\",");
		mailReq.append("\"attachments\": [{");
		mailReq.append("\"fileName\": \"sample.pdf\",");
		mailReq.append("\"byteArrayBase64\": \"" + xlsFile + "\"}");
		mailReq.append("],");
		mailReq.append("\"isConsolidate\":false,");
		mailReq.append("\"isFileAttached\":true,");
		mailReq.append("\"fromEmail\": \"DoNotReply@maxlifeinsurance.com\",");

		mailReq.append("\"mailBody\": \"")
				.append("<html><body>Hi All, <br><br/>Please find the attachment of mPRO-POSV2.0 SIC report."
						+ "<br/><br><br/><br>Regards,<br/><br>Max Life Insurance<br/></body></html>")
				.append("\"");

		mailReq.append("}");
		mailReq.append("}");
		mailReq.append("}");
		return mailReq.toString();
	}

}
