package com.mailsending;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;

public class Base64Converter {

	public static String converter() {
		String base64String = "";
		try {
			String filePath = "C:\\Users\\admin\\Desktop\\New folder\\New folder\\";
			String originalFileName = "POSV Report-2020_05_12 04_57_18.zip";
			byte[] input_file = Files.readAllBytes(Paths.get(filePath + originalFileName));
			byte[] encodedBytes = Base64.getEncoder().encode(input_file);
			base64String = new String(encodedBytes);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		return base64String;
	}
	
	public static void main(String[] args) {
		System.out.println(converter());
	}

}
