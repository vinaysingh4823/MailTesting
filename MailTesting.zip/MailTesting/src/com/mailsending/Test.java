package com.mailsending;

import java.util.Locale;
import java.util.ResourceBundle;

public class Test {
	
	static ResourceBundle bundle = ResourceBundle.getBundle("application", Locale.getDefault());
	public static void main(String[] args) {
		try{
			MailSendingClass.sendEmailToUser(Base64Converter.converter(),"vinaysingh4823@gmail.com");
		}
		catch(Exception ex){
			System.out.println(ex);
		}
	}

}
